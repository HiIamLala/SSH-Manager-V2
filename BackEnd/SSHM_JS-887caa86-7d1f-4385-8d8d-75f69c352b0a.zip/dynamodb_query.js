var AWS = require('aws-sdk');
var dbconverter = AWS.DynamoDB.Converter;

var dynamodb = new AWS.DynamoDB({region:"ap-southeast-1"});

exports.getProjectDetail = (projectID, callback)=>{
    var params = {
      TableName: process.env.dbname,
      Key: {
        'ID': {N: String(projectID)}
      },
      ProjectionExpression: 'ProjectProps'
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            callback(null,{
                statusCode: 200,
                body: (AWS.DynamoDB.Converter.unmarshall(data.Item).ProjectProps)
            });
        }
    });
};

exports.createProject = (project_prop, callback)=>{
    var ID = new Date().getTime();
    var userlist = {};
    userlist[project_prop.ProjectManager] = { "DayAdded": new Date().toISOString()};
    var params = {
        Item: dbconverter.marshall({
            "ID": ID,
            "ProjectProps": project_prop,
            "Users": userlist
        }), 
        ReturnConsumedCapacity: "TOTAL", 
        TableName: process.env.dbname
    };
    dynamodb.putItem(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
            callback(err,{
                statusCode:400,
                body: (err)
            });
        }
        else {
            callback(null,{
                statusCode:200,
                body: ID
            });
        }
    });
};

exports.getProjectInstances = (projectID, callback)=>{
    var params = {
      TableName: process.env.dbname,
      Key: {
        'ID': {N: String(projectID)}
      },
      ProjectionExpression: 'Instances'
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else if(!isEmptyObject(data.Item.Instances)){
            callback(null,{
                statusCode: 200,
                body: (removeSSHKey(dbconverter.unmarshall(data.Item).Instances))
            });
        }
        else{
            callback(null,{
                statusCode: 204,
                body: {}
            });
        }
    });
};

exports.getProjectInstancesAvail = (username, projectID, callback)=>{
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: 'Instances'
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            var temp = dbconverter.unmarshall(data.Item).Instances;
            var result = {};
            Object.keys(temp).forEach(ele=>{
                if(temp[ele].Users && Object.keys(temp[ele].Users).includes(username)){
                    result[ele] = temp[ele];
                }
            });
            callback(null,{
                statusCode: 200,
                body: removeSSHKey(result)
            });
        }
    });
};

exports.adminListProjects = (callback)=>{
    var params = {
        TableName: process.env.dbname,
        ProjectionExpression: "ID, ProjectProps"
    };
    dynamodb.scan(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else{
            var temp = data.Items;
            var result = [];
            temp.forEach(ele=>{
                result.push(dbconverter.unmarshall(ele));
            });
            callback(null, {
                statusCode: 200,
                body: (result)
            });
        }
    });
};

exports.listProjects = (username, callback) =>{
    var params = {
        TableName: process.env.dbname,
        ProjectionExpression: "ID, ProjectProps, #Users",
        ExpressionAttributeNames: { '#Users': 'Users' },
    };
    dynamodb.scan(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else{
            var temp = data.Items;
            var result = [];
            temp.forEach(ele=>{
                if(Object.keys(dbconverter.unmarshall(ele).Users).includes(username))
                    result.push(dbconverter.unmarshall(ele));
            });
            if(result.length)
                callback(null, {
                    statusCode: 200,
                    body: (result)
                });
            else
                callback(null, {
                    statusCode: 204,
                    body: result
                });
        }
    });
};

exports.listProjectUsers = (projectID, callback)=>{
    var params = {
      TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: '#Users',
        ExpressionAttributeNames: {'#Users': 'Users'}
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else if(dbconverter.unmarshall(data.Item).Users) {
            callback(null,{
                statusCode: 200,
                body: (dbconverter.unmarshall(data.Item).Users)
            });
        }
        else{
            callback(null,{
                statusCode: 200,
                body: {}
            });
        }
    });
};

exports.listInstanceUsers = (projectID, instanceID, callback)=>{
    var params = {
      TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: 'Instances',
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else if(dbconverter.unmarshall(data.Item).Instances[instanceID].Users){
            callback(null,{
                statusCode: 200,
                body: (Object.keys(dbconverter.unmarshall(data.Item).Instances[instanceID].Users))
            });
        }
        else{
            callback(null,{
                statusCode: 200,
                body: []
            });
        }
    });
};

exports.updateProjectUsers = (projectID, users, callback)=>{
    if(users.length){
        var params = {
          TableName: process.env.dbname,
            Key: {
                'ID': {N: String(projectID)}
            },
            ProjectionExpression: '#Users',
            ExpressionAttributeNames: {
                "#Users": "Users"
            }
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                callback(err,{
                    statusCode: 400,
                    body: (err)
                });
            }
            else if(dbconverter.unmarshall(data.Item).Users){
                var result = dbconverter.unmarshall(data.Item).Users;
                Object.keys(result).forEach(ele => {
                    if(!users.includes(ele)){
                        delete result[ele];
                    }
                });
                users.forEach(ele => {
                    if(!Object.keys(result).includes(ele)){
                        result[ele] = {"DayAdded": new Date().toISOString()};
                    }
                });
                var params = {
                    TableName: process.env.dbname,
                    Key: {
                        'ID': {N: String(projectID)}
                    },
                    ReturnValues: "UPDATED_NEW",
                    UpdateExpression: "SET #Users = :Users",
                    ExpressionAttributeNames: {
                        "#Users": "Users"
                    }, 
                    ExpressionAttributeValues: {
                        ":Users": dbconverter.marshall({"Users": result}).Users
                    }
                };
                dynamodb.updateItem(params, function(err, data) {
                    if (err) {
                        callback(err,{
                            statusCode: 400,
                            body: (err)
                        });
                    } 
                    else {
                        callback(null,{
                            statusCode: 200,
                            body: (users)
                        });
                    }
                });
            }
            else{
                var result = {};
                users.forEach(ele => {
                    result[ele] = {"DayAdded": new Date().toISOString()};
                });
                var params = {
                    TableName: process.env.dbname,
                    Key: {
                        'ID': {N: String(projectID)}
                    },
                    ReturnValues: "UPDATED_NEW",
                    UpdateExpression: "SET #Users = :Users",
                    ExpressionAttributeNames: {
                        "#Users": "Users"
                    }, 
                    ExpressionAttributeValues: {
                        ":Users": dbconverter.marshall({"Users": result}).Users
                    }
                };
                dynamodb.updateItem(params, function(err, data) {
                    if (err) {
                        callback(err,{
                            statusCode: 400,
                            body: (err)
                        });
                    } 
                    else {
                        callback(null,{
                            statusCode: 200,
                            body: (users)
                        });
                    }
                });
            }
        });
    }
    else {
        var params = {
            TableName: process.env.dbname,
            Key: {
                'ID': {N: String(projectID)}
            },
            ReturnValues: "UPDATED_NEW",
            UpdateExpression: "SET #Users = :Users",
            ExpressionAttributeNames: {
                "#Users": "Users"
            }, 
            ExpressionAttributeValues: {
                ":Users": dbconverter.marshall({"Users": {}}).Users
            }
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                callback(err,{
                    statusCode: 400,
                    body: (err)
                });
            } 
            else {
                callback(null,{
                    statusCode: 200,
                    body: (users)
                });
            }
        });
    }
};

exports.getSSHToken = (username, projectID, instanceID, callback)=>{
    var token = `${new Date().getTime() + 30000}@${username}@${projectID}@${instanceID}@${Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}`;
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ReturnValues: "UPDATED_NEW",
        UpdateExpression: "SET #Instances.#InstanceID.#Users.#Username.#SSHToken = :Token, #Instances.#InstanceID.#Users.#Username.#LastSSH = :now",
        ExpressionAttributeNames: {
            "#Instances": "Instances",
            "#Users": "Users",
            "#InstanceID": instanceID,
            "#Username": username,
            "#SSHToken": "SSHToken",
            "#LastSSH": "LastSSH"
        }, 
        ExpressionAttributeValues: {
            ":Token": {"S":token},
            ":now": {"S": new Date().toISOString()}
        }
    };
    dynamodb.updateItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            callback(null,{
                statusCode: 200,
                body: (token)
            });
        }
    });
};

exports.updateInstanceUser = (projectID, instanceID, users, callback) => {
    var params = {
      TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: '#Instances.#Instance.#Users',
        ExpressionAttributeNames: {
            "#Instances": "Instances",
            "#Instance": String(instanceID),
            "#Users": "Users"
        }
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            var result = dbconverter.unmarshall(data.Item).Instances[instanceID].Users;
            Object.keys(result).forEach(ele => {
                if(!users.includes(ele)){
                    delete result[ele];
                }
            });
            users.forEach(ele => {
                if(!Object.keys(result).includes(ele)){
                    result[ele] = {"DayAdded": new Date().toISOString()};
                }
            });
            var updateData = dbconverter.marshall({"Users": result});
            var params = {
                TableName: process.env.dbname,
                Key: {
                    'ID': {N: String(projectID)}
                },
                ReturnValues: "UPDATED_NEW",
                UpdateExpression: "SET #Instances.#Instance.#Users = :Users",
                ExpressionAttributeNames: {
                    "#Users": "Users",
                    "#Instances": "Instances",
                    "#Instance": String(instanceID)
                }, 
                ExpressionAttributeValues: {
                    ":Users": updateData.Users
                }
            };
            dynamodb.updateItem(params, function(err, data) {
                if (err) {
                    callback(err,{
                        statusCode: 400,
                        body: (err)
                    });
                } 
                else {
                    callback(null,{
                        statusCode: 200,
                        body: (users)
                    });
                }
            });
        }
    });
};

exports.updateInstanceDetail = (instanceProps, projectID, instanceID, callback)=>{
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ReturnValues: "UPDATED_NEW",
        UpdateExpression: "SET #Instances.#Instance.#InstanceProps = :InstanceProps",
        ExpressionAttributeNames: {
            "#InstanceProps": "InstanceProps",
            "#Instances": "Instances",
            "#Instance": String(instanceID)
        }, 
        ExpressionAttributeValues: {
            ":InstanceProps": dbconverter.marshall({"InstanceProps" : instanceProps}).InstanceProps
        }
    };
    dynamodb.updateItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            callback(null,{
                statusCode: 200,
                body: (instanceProps)
            });
        }
    });
};

exports.getInstanceDetail = (projectID, instanceID, callback)=>{
    var params = {
      TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: '#Instances.#Instance.#InstanceProps',
        ExpressionAttributeNames: {
            "#Instances": "Instances",
            "#Instance": String(instanceID),
            "#InstanceProps": "InstanceProps"
        }
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else {
            callback(null,{
                statusCode: 200,
                body: (dbconverter.unmarshall(data.Item).Instances[instanceID].InstanceProps)
            });
        }
    });
};

exports.removeInstance = (projectID, instanceID, callback)=>{
    var params = {
      TableName: process.env.dbname,
      Key: {
        'ID': {N: String(projectID)}
      },
      ProjectionExpression: 'Instances'
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else if(!isEmptyObject(data.Item.Instances)){
            var instances = dbconverter.unmarshall(data.Item).Instances;
            delete instances[instanceID];
            var params = {
                TableName: process.env.dbname,
                Key: {
                    'ID': {N: String(projectID)}
                },
                ReturnValues: "UPDATED_NEW",
                UpdateExpression: "SET #Instances = :Instances",
                ExpressionAttributeNames: {
                    "#Instances": "Instances"
                }, 
                ExpressionAttributeValues: {
                    ":Instances": dbconverter.marshall({"Instances":instances}).Instances
                }
            };
            dynamodb.updateItem(params, function(err, data) {
                if (err) {
                    callback(err,{
                        statusCode: 400,
                        body: (err)
                    });
                } 
                else {
                    callback(null,{
                        statusCode: 200,
                        body: "Successfully deleted"
                    });
                }
            });
        }
        else{
            callback(null,{
                statusCode: 204,
                body: {}
            });
        }
    });
};

exports.removeProject = (projectID, callback)=>{
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        }
    };
    dynamodb.deleteItem(params, function(err, data) {
        if (err){
            console.log(err, err.stack); // an error occurred
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        }
        else{
            callback(null,{
                statusCode: 200,
                body: "Successfully deleted"
            });
        }
    });
};

exports.isProjectManager = (username, projectID, callback)=>{
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: 'ProjectProps'
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err, false);
        }
        else {
            if(dbconverter.unmarshall(data.Item).ProjectProps.ProjectManager == username){
                callback(null, true);
            }
            else{
                callback(null,false);
            }
        }
    });
};

exports.isProjectDeveloper = (username, projectID, callback)=>{
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: '#Users',
        ExpressionAttributeNames: {'#Users': 'Users'}
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,false);
        }
        else {
            if(Object.keys(dbconverter.unmarshall(data.Item).Users).includes(username)){
                callback(null, true);
            }
            else{
                callback(null,false);
            }
        }
    });
};

exports.isInstanceDeveloper = (username, projectID, instanceID, callback) => {
    var params = {
        TableName: process.env.dbname,
        Key: {
            'ID': {N: String(projectID)}
        },
        ProjectionExpression: "Instances"
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            callback(err,false);
            return false;
        }
        else {
            callback(null, Object.keys(dbconverter.unmarshall(data.Item).Instances[instanceID].Users).includes(username));
        }
    });
};

exports.listAllInstances = (callback) => {
    var params = {
        TableName: process.env.dbname,
        ProjectionExpression: "ID, Instances, ProjectProps"
    };
    dynamodb.scan(params, function(err, data) {
        if (err) {
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        } 
        else{
            var temp = data.Items;
            var result = [];
            temp.forEach(ele=>{
                var temp = dbconverter.unmarshall(ele);
                if(temp.Instances){
                    Object.keys(temp.Instances).forEach(instance=>{
                        delete(temp.Instances[instance].SSHKey);
                    });
                    result.push(temp);
                }
            });
            callback(null, {
                statusCode: 200,
                body: (result)
            });
        }
    });
};

function removeSSHKey(list){
    Object.keys(list).forEach(ele=>{
        delete list[ele]['SSHKey'];
        delete list[ele]['Users'];
    });
    return list;
}

function isEmptyObject(obj) {
    for ( var name in obj ) {
        return false;
    }
    return true;
}