var AWS = require("aws-sdk");
var s3 = new AWS.S3({region: 'ap-southeast-1'});


exports.getAllListLog = (callback)=>{
    function getLog(result, ContinuationToken) {
        var params = {
          Bucket: process.env.sshLogBucket,
          ContinuationToken: ContinuationToken,
        };
        s3.listObjectsV2(params, function(err, data) {
          if (err) {
              console.log(err, err.stack); // an error occurred
              callback(err,{
                    statusCode: 400,
                    body: (err)
                });
          }
          else {
              if(data.isTruncated){
                  data.Contents.forEach(ele=>{
                      var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                  });
                  getLog(data.NextContinuationToken);
              }
              else{
                  callback(null,{
                      statusCode:200,
                      body: result
                  });
              }
          }
        });
    }
    var res = {};
    var params = {
        Bucket: process.env.sshLogBucket
    };
    s3.listObjectsV2(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        }
        else {
            if(data.isTruncated){
                data.Contents.forEach(ele=>{
                    var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                });
                getLog(res, data.NextContinuationToken);
            }
            else{
                data.Contents.forEach(ele=>{
                    var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                });
                callback(null,{
                    statusCode:200,
                    body: res
                });
            }
        }
    });
};

exports.getLogOfInstance = (projectID,instanceID,callback)=>{
    function getLog(result, ContinuationToken) {
        var params = {
          Bucket: process.env.sshLogBucket,
          ContinuationToken: ContinuationToken,
          Prefix: `${projectID}/${instanceID}/`,
        };
        s3.listObjectsV2(params, function(err, data) {
          if (err) {
              console.log(err, err.stack); // an error occurred
              callback(err,{
                    statusCode: 400,
                    body: (err)
                });
          }
          else {
              if(data.isTruncated){
                  data.Contents.forEach(ele=>{
                      var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                  });
                  getLog(data.NextContinuationToken);
              }
              else{
                  callback(null,{
                      statusCode:200,
                      body: result
                  });
              }
          }
        });
    }
    var res = {};
    var params = {
        Bucket: process.env.sshLogBucket,
        Prefix: `${projectID}/${instanceID}/`,
    };
    s3.listObjectsV2(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        }
        else {
            if(data.isTruncated){
                data.Contents.forEach(ele=>{
                    var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                });
                getLog(res, data.NextContinuationToken);
            }
            else{
                data.Contents.forEach(ele=>{
                    var temp = {};
                    if(res[ele.Key.split('/')[0]] == undefined){
                        res[ele.Key.split('/')[0]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                        res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                    }
                    else{
                        if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] == undefined){
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]] = {};
                             res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                        }
                        else{
                            if(res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] == undefined){
                                res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]] = {};
                            }
                        }
                    }
                    temp.name = ele.Key.split('/')[3];
                    temp.size = ele.Size;
                    res[ele.Key.split('/')[0]][ele.Key.split('/')[1]][ele.Key.split('/')[2]][ele.Key.split('/')[3].split('_')[0]] = (temp);
                });
                callback(null,{
                    statusCode:200,
                    body: res
                });
            }
        }
    });
};

exports.getLogData = (projectID,instanceID,username,logname,offset,callback)=>{
    var params = {
        Bucket: process.env.sshLogBucket,
        Key: `${projectID}/${instanceID}/${username}/${logname}`
    };
    s3.getObject(params, function(err, data) {
        if (err) {
            console.log(err, err.stack); // an error occurred
            callback(err,{
                statusCode: 400,
                body: (err)
            });
        }
        else{
            callback(null, {
                statusCode:200,
                body: data.Body.toString().slice(parseInt(offset)||0, (parseInt(offset)||0)+4716000),
                size: data.Body.length,
                nextoffset: parseInt(offset)+4716000
            });
        }
    });
};