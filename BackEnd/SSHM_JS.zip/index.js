var cognito = require('./cognito_query');
var db = require('./dynamodb_query');
var log = require('./log_query');

exports.handler = (event,context,callback) => {
    console.log(({"time":new Date().toISOString(),"event": event}));
    try{
        switch(event.context['resource-path']){
            case "/login":
                cognito.login(event['body-json'].username,event['body-json'].password,callback);
                break;
            case "/googlelogin":
                cognito.GLogin(event.context.identity.username,event.params.querystring.accesstoken,callback);
                break;
            case "/register":
                cognito.register(event['body-json'].username,event['body-json'].email,callback);
                break;
            case "/challengerep":
                cognito.challengeRep(event['body-json'],callback);
                break;
            case "/reauth":
                cognito.reAuth(event['body-json'].username, event['body-json'].refreshToken, callback);
                break;
            case "/getalluserdetail":
                cognito.listAllUserDetail(callback);
                break;
            case "/listalluser":
                cognito.listAllUsername(callback);
                break;
            case "/getuserdetail":
                cognito.getUserDetail(event.params.querystring.username,callback);
                break;
            case "/changepassword":
                cognito.changePassword(event['body-json'].accessToken,event['body-json'].prePass,event['body-json'].newPass,callback);
                break;
            case "/listalllog":
                if(isAdmin(event)){
                    log.getAllListLog(callback);
                }
                else{
                    callback(null,{
                        statusCode:403,
                        body:"Forbidden"
                    });
                }
                break;
            case "/listinstancelog":
                if(isAdmin(event)){
                    log.getLogOfInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            log.getLogOfInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            db.isInstanceDeveloper(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, (err2,result2)=>{
                                if(err2){
                                    callback(null,{
                                        statusCode: 400,
                                        body: ("Bad request")
                                    });
                                }
                                else if(result2){
                                    log.getLogOfInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                                }
                                else{
                                    callback(null,{
                                        statusCode: 403,
                                        body: ("Forbidden")
                                    });
                                }
                            });
                        }
                    });
                }
                break;
            case "/getlogdata":
                if(isAdmin(event)){
                    log.getLogData(event.params.querystring.projectid, event.params.querystring.instanceid, event.params.querystring.username, event.params.querystring.logname, event.params.querystring.offset, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            log.getLogData(event.params.querystring.projectid, event.params.querystring.instanceid, event.params.querystring.username, event.params.querystring.logname, event.params.querystring.offset, callback);
                        }
                        else{
                            db.isInstanceDeveloper(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, (err2,result2)=>{
                                if(err2){
                                    callback(null,{
                                        statusCode: 400,
                                        body: ("Bad request")
                                    });
                                }
                                else if(result2){
                                    log.getLogData(event.params.querystring.projectid, event.params.querystring.instanceid, event.params.querystring.username, event.params.querystring.logname, event.params.querystring.offset, callback);
                                }
                                else{
                                    callback(null,{
                                        statusCode: 403,
                                        body: ("Forbidden")
                                    });
                                }
                            });
                        }
                    });
                }
                break;
            case "/removeuser":
                if(isAdmin(event)){
                    cognito.removeUser(event.params.querystring.username,callback);
                }
                else{
                    callback(null,{
                        statusCode:403,
                        body:"Forbidden"
                    });
                }
                break;
            case "/createinstance":
                if(isAdmin(event)){
                    var InstanceDetail = {
                        "InstanceProps":{
                            "InstanceName": event['body-json'].instance_name,
                            "ARN": event['body-json'].instance_arn,
                            "InstanceUser": event['body-json'].instance_user,
                            "IPAddress": event['body-json'].instance_ip,
                            "Bastion": event['body-json'].bastion
                        }
                    };
                    if(event['body-json'].instance_ssh){
                        InstanceDetail.SSHKey = event['body-json'].instance_ssh;
                    }
                    else if(event['body-json'].instance_pass && event['body-json'].instance_pass.length > 0){
                        InstanceDetail.SSHPassword = event['body-json'].instance_pass;
                    }
                    db.createInstance(event['body-json'].ID,InstanceDetail,callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event['body-json'].ID,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            var InstanceDetail = {
                                "InstanceProps":{
                                    "InstanceName": event['body-json'].instance_name,
                                    "ARN": event['body-json'].instance_arn,
                                    "InstanceUser": event['body-json'].instance_user,
                                    "IPAddress": event['body-json'].instance_ip
                                }
                            };
                            if(event['body-json'].instance_ssh){
                                InstanceDetail.SSHKey = event['body-json'].instance_ssh;
                            }
                            else if(event['body-json'].instance_pass && event['body-json'].instance_pass.length > 0){
                                InstanceDetail.SSHPassword = event['body-json'].instance_pass;
                            }
                            db.createInstance(event['body-json'].ID,InstanceDetail,callback);
                        }
                        else{
                            callback(null,{
                                statusCode: 403,
                                body: "Forbidden"
                            });    
                        }
                    });
                }
                break;
            case "/deleteinstance":
                if(isAdmin(event)){
                    db.removeInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            db.removeInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            callback(null,{
                                statusCode: 403,
                                body: "Forbidden"
                            });    
                        }
                    });
                }
                break;
            case "/removeinstance":
                if(isAdmin(event)){
                    db.removeInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            db.removeInstance(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            callback(null,{
                                statusCode: 403,
                                body: "Forbidden"
                            });    
                        }
                    });
                }
                break;
            case "/update-project-detail":
                if(isAdmin(event)){
                    db.updateProjectDetail(event['body-json'].ID, {"CompanyName": event['body-json']["company_name"],
                        "ProjectManager": event['body-json']["project_manager"],"ProjectName": event['body-json']["project_name"]}, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,(err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                             });
                        }
                        else if(result){
                            db.updateProjectDetail(event['body-json'].ID, {"CompanyName": event['body-json']["company_name"],
                                "ProjectManager": event['body-json']["project_manager"],"ProjectName": event['body-json']["project_name"]}, callback);
                        }
                        else{
                            callback(null,{
                                statusCode: 403,
                                body: "Forbidden"
                            });    
                        }
                    });
                }
                break;
            case "/removeproject":
                if(isAdmin(event)){
                    db.removeProject(event.params.querystring.id, callback);
                }
                else{
                    callback(null,{
                        statusCode: 403,
                        body: "Forbidden"
                    });
                }
                break;
            case "/updateuserdetail":
                if(isAdmin(event) || event.context.identity.username == event['body-json'].username){
                    cognito.updateUserDetail(event['body-json'].username, event['body-json'].props,callback);
                }
                else{
                    callback(null,{
                        statusCode: 403,
                        body: "Forbidden!"
                    });
                }
                break;
            case "/projectdetail":
                if(!isNaN(event.params.querystring.id))
                    db.getProjectDetail(event.params.querystring.id,callback);
                else
                    callback(null,{
                        statusCode: 400,
                        body: ("Bad request!")
                    });
                break;
            case "/createproject":
                if(isAdmin(event)){
                    if(event['body-json'].projectprops)
                        db.createProject(event['body-json'].projectprops,callback);
                        // callback(null,{
                        //     statusCode:200,
                        //     body:event['body-json'].projectprops
                        // });
                    else
                        callback(null,{
                            statusCode: 400,
                            body: ("Bad request!")
                        });
                }
                else{
                    callback(null,{
                        statusCode: 403,
                        body: ("Forbidden!")
                    });
                }
                break;
            case "/listprojectinstances":
                if(!isNaN(event.params.querystring.id)){
                    if(isAdmin(event)){
                        db.getProjectInstances(event.params.querystring.id, callback);
                    }
                    else
                    {
                        db.isProjectManager(event.context.identity.username, event.params.querystring.id,(err,result)=>{
                            if(err){
                                callback(null,{
                                    statusCode: 400,
                                    body: "Bad Request"
                                });
                            }
                            else if(result){
                                 db.getProjectInstances(event.params.querystring.id, callback);
                            }
                            else{
                                db.isProjectDeveloper(event.context.identity.username, event.params.querystring.id, (err,result)=>{
                                    if(err){
                                        callback(null, {
                                            statusCode:400,
                                            body: "Bad request"
                                        });
                                    }
                                    else if(result){
                                        db.getProjectInstancesAvail(event.context.identity.username, event.params.querystring.id, callback);
                                    }
                                    else {
                                        callback(null, {
                                            statusCode: 403,
                                            body: ("Forbidden!")
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
                else{
                    callback(null, {
                        statusCode:400,
                        body: "Bad request"
                    });
                }
                break;
            case "/listprojects":
                if(isAdmin(event)){
                    db.adminListProjects(callback);
                }
                else{
                    db.listProjects(event.context.identity.username, callback);
                }
                break;
            case "/listprojectusers":
                if(isAdmin(event)){
                    db.listProjectUsers(event.params.querystring.id, callback);
                }
                else{
                    db.isProjectDeveloper(event.context.identity.username, event.params.querystring.id, (err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: "Bad Request"
                            });
                        }
                        else if(result){
                            db.listProjectUsers(event.params.querystring.id, callback);
                        }
                        else{
                            callback(null,{
                                statusCode: 403,
                                body: "Forbidden"
                            });
                        }
                    });
                }
                break;
            case "/listinstanceusers":
                if(isAdmin(event)){
                    db.listInstanceUsers(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid, (err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: ("Bad request")
                            });
                        }
                        else if(result){
                            db.listInstanceUsers(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            db.isInstanceDeveloper(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, (err2,result2)=>{
                                if(err2){
                                    callback(null,{
                                        statusCode: 400,
                                        body: ("Bad request")
                                    });
                                }
                                else if(result2){
                                    db.listInstanceUsers(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                                }
                                else{
                                    callback(null,{
                                        statusCode: 403,
                                        body: ("Forbidden")
                                    });
                                }
                            });
                        }
                    });
                }
                break;
            case "/updateprojectusers":
                if(!isNaN(event['body-json'].projectID)){
                    if(isAdmin(event)){
                        db.updateProjectUsers(event['body-json'].projectID, event['body-json'].users, callback);
                    }
                    else {
                        db.isProjectManager(event.context.identity.username, event['body-json'].projectID, (err,result)=>{
                            if(err){
                                callback(null,{
                                    statusCode: 400,
                                    body: "Bad Request"
                                });
                            }
                            else if(result){
                                db.updateProjectUsers(event['body-json'].projectID, event['body-json'].users, callback);
                            }
                            else{
                                callback(null,{
                                    statusCode: 403,
                                    body: "Forbidden"
                                });
                            }
                        });
                    }
                }
                else{
                    callback(null,{
                        statusCode: 400,
                        body: (event['body-json'].users)
                    });
                }
                break;
            case "/sshconnect":
                if(isAdmin(event)){
                    db.getSSHToken(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isInstanceDeveloper(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, (err,result)=>{
                        if(err){
                            callback(null, {
                                statusCode: 400,
                                body: ("Bad Request")
                            });
                        }
                        else if(result){
                            db.getSSHToken(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            callback(null, {
                                statusCode: 403,
                                body: ("Forbidden")
                            });
                        }
                    });
                }
                break;
            case "/updateinstanceusers":
                if(isAdmin(event)){
                    db.updateInstanceUser(event['body-json'].projectID, event['body-json'].instanceID, event['body-json'].users, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event['body-json'].projectID, (err,result)=>{
                        if(err){
                            callback(null, {
                                statusCode: 400,
                                body: ("Bad Request")
                            });
                        }
                        else if(result){
                            db.updateInstanceUser(event['body-json'].projectID, event['body-json'].instanceID, event['body-json'].users, callback);
                        }
                        else {
                            callback(null, {
                                statusCode: 403,
                                body: ("Forbidden")
                            });
                        }
                    });
                }
                break;
            case "/updateinstancedetail":
                if(isAdmin(event)){
                    db.updateInstanceDetail(event['body-json'].instanceProps, event['body-json'].projectID, event['body-json'].instanceID, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event['body-json'].projectID, (err,result)=>{
                        if(err){
                            callback(null, {
                                statusCode: 400,
                                body: ("Bad Request")
                            });
                        }
                        else if(result){
                            db.updateInstanceDetail(event['body-json'].instanceProps, event['body-json'].projectID, event['body-json'].instanceID, callback);
                        }
                        else{
                            callback(null, {
                                statusCode: 403,
                                body: ("Forbidden")
                            });
                        }
                    });
                }
                break;
            case "/getinstancedetail":
                if(isAdmin(event)){
                    db.getInstanceDetail(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                }
                else{
                    db.isProjectManager(event.context.identity.username, event.params.querystring.projectid,  (err,result)=>{
                        if(err){
                            callback(null,{
                                statusCode: 400,
                                body: ("Bad request")
                            });
                        }
                        else if(result){
                            db.getInstanceDetail(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                        }
                        else{
                            db.isInstanceDeveloper(event.context.identity.username, event.params.querystring.projectid, event.params.querystring.instanceid, (err2,result2)=>{
                                if(err2){
                                    callback(null,{
                                        statusCode: 400,
                                        body: ("Bad request")
                                    });
                                }
                                else if(result2){
                                    db.getInstanceDetail(event.params.querystring.projectid, event.params.querystring.instanceid, callback);
                                }
                                else{
                                    callback(null,{
                                        statusCode: 403,
                                        body: ("Forbidden")
                                    });
                                }
                            });
                        }
                    });
                }
                break;
            case "/listallinstances":
                if(isAdmin(event)){
                    db.listAllInstances(callback);
                }
                else{
                    callback(null,{
                        statusCode: 403,
                        body: ("Forbidden")
                    });
                }
                break;
            default:
                callback(null,{
                    statusCode: 400,
                    body: ("Unknow request!"),
                    request: event,
                });
        }
    } catch(err){
        console.log(err);
        callback(null,{
            statusCode: 500,
            body: ("Server error! Beep beep.. boop boop.."),
            err: (err)
        });
    }
};

function isAdmin(evt){
    if(evt.context.identity['groups'].includes('admin')){
        return true;
    }
    else{
        return false;
    }
}