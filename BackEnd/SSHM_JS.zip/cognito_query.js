var AWS = require("aws-sdk");
var crypto = require('crypto');

var clientId = process.env.clientID;
var clientSecret = process.env.clientSecret;
var userPoolId = process.env.userPoolID;

var cognito = new AWS.CognitoIdentityServiceProvider({region: 'ap-southeast-1'});

exports.login = (username,password,callback) => {
  // TODO implement
  var params = {
    AuthFlow: 'USER_PASSWORD_AUTH',
    ClientId: clientId,
    AuthParameters: { 'USERNAME':username,
      'PASSWORD':password,
      'SECRET_HASH': getHash(username)
    }
  };
  try{
    cognito.initiateAuth(params, function(err, data) {
      if (err){
        console.log(err, err.stack);
        callback(err,{
          statusCode: 400,
          body: (err)
        });
      }
      else if(data.AuthenticationResult){
        var params = {
          UserPoolId: userPoolId,
          Username: username
        };
        cognito.adminListGroupsForUser(params, function(err2, data2) {
          if(err2){
            callback(err,{
              statusCode: 400,
              body: (err)
            });
          }
          else{
            var groups = data2.Groups;
            var isAdmin = false;
            groups.forEach(ele=>{
              if(ele.GroupName == "admin"){
                isAdmin = true;
              }
            });
            data.AuthenticationResult.isAdmin = isAdmin;
            data.AuthenticationResult.username = username;
            callback(null,{
              statusCode: 200,
              body: (data)
            });
          }
        });
      }
      else{
        callback(null,{
          statusCode: 200,
          body: (data)
        });
      }
    });
  } catch(err) {
      callback(err,{
          statusCode: 400,
          body: (err)
      });
  }
};

exports.GLogin = (username,accessToken, callback)=>{
  var params = {
    AccessToken: accessToken
  };
  cognito.getUser(params, function(err, data) {
    if (err) {
      console.log(err, err.stack);
      callback(err,null);
    }
    else {
      if(username==data.Username){
        var params = {
          UserPoolId: userPoolId,
          Username: username
        };
        cognito.adminListGroupsForUser(params, function(err2, data2) {
          if(err2){
            callback(err,{
              statusCode: 400,
              body: (err)
            });
          }
          else{
            var groups = data2.Groups;
            var isAdmin = false;
            groups.forEach(ele=>{
              if(ele.GroupName == "admin"){
                isAdmin = true;
              }
            });
            callback(null,{
              statusCode: 200,
              body: {
                'isAdmin': isAdmin,
                'username': username
              }
            });
          }
        });
      }
    }
  });
};

exports.getAllUser = (callback)=>{
  var result = [];
  var getUserList = (token, callback)=>{
    var params = {
      UserPoolId: userPoolId
    };
    cognito.listUsers(params, function(err, data) {
      if (err) {
        console.log(err, err.stack);
        callback(err,null);
      }
      else{
        Array.prototype.push.apply(result,data.Users);
        if(data.PaginationToken){
          getUserList(data.PaginationToken);
        }
        else{
          callback(null,result);
        }
      }
    });
  };
  getUserList(null, callback);
};

exports.listAllUsername = (callback) => {
  exports.getAllUser((err,result)=>{
    if(err){
      callback(err, null);
    }
    else{
      var res = [];
      result.forEach(ele=>{
        res.push(ele.Username);
      });
      callback(null, {
        statusCode:200,
        body: (res)
      });
    }
  });
};

exports.reAuth = (username,RefreshToken,callback) => {
  var params = {
    AuthFlow: 'REFRESH_TOKEN_AUTH',
    ClientId: clientId,
    AuthParameters: { 'REFRESH_TOKEN':RefreshToken,
      'SECRET_HASH': getHash(username)
    }
  };
  try{
    cognito.initiateAuth(params, function(err, data) {
        if (err){
          console.log(err, err.stack);
          callback(err,{
            statusCode: 400,
            body: (err)
          });
        }
        else if(data.AuthenticationResult){
          var params = {
            UserPoolId: userPoolId,
            Username: username
          };
          cognito.adminListGroupsForUser(params, function(err2, data2) {
            if(err2){
              callback(err,{
                statusCode: 400,
                body: (err)
              });
            }
            else{
              var groups = data2.Groups;
              var isAdmin = false;
              groups.forEach(ele=>{
                if(ele.GroupName == "admin"){
                  isAdmin = true;
                }
              });
              data.AuthenticationResult.isAdmin = isAdmin;
              callback(null,{
                statusCode: 200,
                body: (data)
              });
            }
          });
        }
        else{
          callback(null,{
            statusCode: 200,
            body: (data)
          });
        }
    });
    } catch(err) {
        callback(err,{
            statusCode: 400,
            body: (err)
        });
    }
};

exports.register = (username, email, callback)=>{
  var params = {
    UserPoolId: userPoolId,
    Username: username,
    DesiredDeliveryMediums: [
      "EMAIL"
    ],
    UserAttributes: [
      {
        Name: 'email',
        Value: email
      }
    ]
  };
  cognito.adminCreateUser(params, function(err, data) {
    if (err){
      console.log(err, err.stack);
      callback(err,{
        statusCode:400,
        body: "Error occurred."
      });
    }
    else{
      callback(null, {
        statusCode:200,
        body: "We have sent an email to verify your email address"
      });
    }
  });
};

exports.challengeRep = (challengeRepProps, callback)=>{
  switch(challengeRepProps.ChallengeName){
    case "NEW_PASSWORD_REQUIRED":
      var params = {
        ChallengeName: challengeRepProps.ChallengeName,
        ClientId: clientId,
        ChallengeResponses: {
          'NEW_PASSWORD_REQUIRED': "NEW_PASSWORD",
          'NEW_PASSWORD': challengeRepProps.NewPassword,
          'SECRET_HASH': getHash(challengeRepProps.Username),
          'USERNAME': challengeRepProps.Username
        },
        Session: challengeRepProps.Session
      };
      cognito.respondToAuthChallenge(params, function(err, data) {
        if (err) {
          console.log(err, err.stack); // an error 
          callback(err, {
            statusCode:400,
            body: err
          });
        }
        else if(data.AuthenticationResult){
          var params = {
            UserPoolId: userPoolId,
            Username: challengeRepProps.Username
          };
          cognito.adminListGroupsForUser(params, function(err2, data2) {
            if(err2){
              console.log(err2, err2.stack); // an error 
              callback(err2, {
                statusCode:400,
                body: err2
              });
            }
            else{
              var groups = data2.Groups;
              var isAdmin = false;
              groups.forEach(ele=>{
                if(ele.GroupName == "admin"){
                  isAdmin = true;
                }
              });
              data.AuthenticationResult.isAdmin = isAdmin;
              data.AuthenticationResult.username = challengeRepProps.Username;
              callback(null,{
                statusCode: 200,
                body: (data)
              });
            }
          });
        }
        else{
          callback(null,{
            statusCode:200,
            body: data
          });
        }
      });
      break;
    default:
      callback(400,{
        statusCode:400,
        body: "Bad Request"
      });
  }
};

exports.listAllUserDetail = (callback) =>{
  exports.getAllUser((err,result)=>{
    if(err){
      callback(err, null);
    }
    else{
      result.forEach(ele=>{
        delete ele.Enabled;
        delete ele.UserStatus;
      });
      callback(null, {
        statusCode:200,
        body: (result)
      });
    }
  });
};

exports.getUserDetail = (username, callback)=>{
  var params = {
    UserPoolId: userPoolId,
    Username: username
  };
  cognito.adminGetUser(params, function(err, data) {
    if (err) {
      console.log(err, err.stack); // an error 
      callback(err, {
        statusCode:400,
        body: err
      });
    }
    else{
      delete data.Enabled;
      delete data.UserStatus;
      callback(null,{
        statusCode:200,
        body: data
      });
    }         // successful response
  });
};

exports.changePassword = (accessToken,prePass,newPass,callback)=>{
  var params = {
    AccessToken: accessToken,
    PreviousPassword: prePass,
    ProposedPassword: newPass,
  };
  cognito.changePassword(params, function(err, data) {
    if (err) {
      console.log(err, err.stack); // an error 
      callback(err, {
        statusCode:400,
        body: err
      });
    }
    else{
      callback(null, {
        statusCode:200,
        body: "Successfully"
      });
    }
  });
};

exports.removeUser = (username,callback)=>{
  var params = {
    UserPoolId: userPoolId,
    Username: username
  };
  cognito.adminDeleteUser(params, function(err, data) {
    if (err) {
      console.log(err, err.stack);
      callback(err, {
        statusCode:400,
        body: err
      });
    }
    else{
      callback(null,{
        statusCode:200,
        body: "Removed user" + username
      });
    }
  });
};

exports.updateUserDetail = (username, props,callback)=>{
  var newAttrs = [];
  Object.keys(props).forEach(ele=>{
    newAttrs.push({
      Name: ele,
      Value: props[ele]
    });
  });
  var params = {
    UserAttributes: newAttrs,
    UserPoolId: userPoolId,
    Username: username
  };
  cognito.adminUpdateUserAttributes(params, function(err, data) {
    if (err) {
      console.log(err, err.stack); // an error 
      callback(err, {
        statusCode:400,
        body: err
      });
    }
    else{
      callback(null, {
        statusCode:200,
        body: "Successfully"
      });
    }
  });
};

function getHash(username){
  var dataString = username + clientId;
  var data = Buffer.from(dataString).toString('utf8');
  var key = Buffer.from(clientSecret).toString('utf8');
  return crypto.createHmac('sha256', key).update(data).digest('base64');
}